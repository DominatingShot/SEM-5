#include <bits/stdc++.h>
using namespace std;
int smallest(vector<int> v){
    return v[0];
}
int largest(vector<int> v){
    return v[v.size()-1];
}